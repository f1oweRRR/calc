import SwiftUI

@main
struct caclApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(GlobalDisplayEnv())
        }
    }
}
